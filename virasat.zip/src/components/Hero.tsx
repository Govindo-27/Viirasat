import React from "react";
import { ArrowRight, BookOpen, Feather, Sparkles } from "lucide-react";

interface HeroProps {
  onNavigateToArchive: () => void;
  onNavigateToPreserve: () => void;
  onNavigateToAsk: () => void;
  traditionsCount: number;
}

export const Hero: React.FC<HeroProps> = ({
  onNavigateToArchive,
  onNavigateToPreserve,
  onNavigateToAsk,
  traditionsCount,
}) => {
  return (
    <section className="relative overflow-hidden border-b border-[#E5DDD0] bg-[#FAF7F2] py-14 sm:py-20">
      {/* Background Archival Grid & Subtle Ambient Glow */}
      <div
        className="absolute inset-0 pointer-events-none opacity-40 heritage-pattern"
        aria-hidden="true"
      />
      <div
        className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-[#A64B2A]/5 blur-3xl pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-[#1B4332]/5 blur-3xl pointer-events-none"
        aria-hidden="true"
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl animate-fade-in">
          {/* Quiet Archival Label */}
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#A64B2A] font-semibold mb-4">
            <span>Open Cultural Heritage Archive</span>
            <span aria-hidden="true">·</span>
            <span>Cloud AI Curation Engine</span>
          </div>

          {/* Main Title & Tagline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-[#1B4332] tracking-tight leading-[1.15] text-balance">
            Every tradition deserves a tomorrow.
          </h1>

          <p className="mt-5 text-base sm:text-lg text-[#554F45] leading-relaxed max-w-2xl">
            Virasat is a community-anchored cultural archive dedicated to documenting indigenous oral
            histories, ancient artisanal crafts, living folk practices, regional recipes, and sacred
            festivals. With cloud AI curation, we summarize, translate, and cross-reference ancestral
            memory instantly—while preserving the original voice unchanged.
          </p>

          {/* Unverified Archive Disclaimer Banner */}
          <div className="mt-6 p-4 rounded-lg bg-[#F3ECE1]/80 backdrop-blur-xs border border-[#E5DDD0] text-xs text-[#6B655B] leading-relaxed shadow-2xs">
            <span className="font-semibold text-[#1B4332]">Archival Integrity Note:</span> Virasat
            preserves living folk memories directly from community custodians. AI annotations and
            translations are generated for cultural accessibility and remain unverified community
            contributions rather than institutional academic certifications.
          </div>

          {/* Primary Action Buttons */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button
              onClick={onNavigateToArchive}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1B4332] text-white rounded-md text-sm font-semibold hover:bg-[#2D6A4F] hover:shadow-sm active:scale-[0.98] transition-all cursor-pointer shadow-xs"
            >
              <BookOpen size={16} />
              <span>Explore Archive</span>
            </button>
            <button
              onClick={onNavigateToPreserve}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-white border border-[#D5C9B7] text-[#1B4332] rounded-md text-sm font-semibold hover:bg-[#F3ECE1] hover:border-[#1B4332]/40 active:scale-[0.98] transition-all cursor-pointer shadow-2xs"
            >
              <Feather size={16} />
              <span>Preserve a Tradition</span>
            </button>
            <button
              onClick={onNavigateToAsk}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-[#A64B2A] hover:text-[#88361B] text-sm font-medium hover:translate-x-0.5 transition-all cursor-pointer"
            >
              <Sparkles size={16} />
              <span>Ask Archive Curator</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>

        {/* Operational Statistics Strip */}
        <div className="mt-12 pt-8 border-t border-[#E5DDD0] grid grid-cols-2 sm:grid-cols-4 gap-6 text-left">
          <div className="group">
            <div className="text-2xl sm:text-3xl font-serif font-bold text-[#1B4332] tabular-nums transition-transform group-hover:translate-y-[-1px]">
              {traditionsCount}
            </div>
            <div className="text-xs uppercase tracking-wider text-[#6B655B] mt-0.5 font-medium">
              Preserved Traditions
            </div>
          </div>
          <div className="group">
            <div className="text-2xl sm:text-3xl font-serif font-bold text-[#1B4332] tabular-nums transition-transform group-hover:translate-y-[-1px]">
              8+
            </div>
            <div className="text-xs uppercase tracking-wider text-[#6B655B] mt-0.5 font-medium">
              Regional Tongues
            </div>
          </div>
          <div className="group">
            <div className="text-2xl sm:text-3xl font-serif font-bold text-[#1B4332] tabular-nums transition-transform group-hover:translate-y-[-1px]">
              7
            </div>
            <div className="text-xs uppercase tracking-wider text-[#6B655B] mt-0.5 font-medium">
              Cultural Domains
            </div>
          </div>
          <div className="group">
            <div className="text-2xl sm:text-3xl font-serif font-bold text-[#A64B2A] font-semibold transition-transform group-hover:translate-y-[-1px]">
              Instant AI
            </div>
            <div className="text-xs uppercase tracking-wider text-[#6B655B] mt-0.5 font-medium">
              Cloud Heritage Curator
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
