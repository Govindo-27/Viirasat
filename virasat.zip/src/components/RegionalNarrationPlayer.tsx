import React, { useState, useEffect, useRef } from "react";
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Loader2,
  Globe2,
  Copy,
  Check,
  Headphones,
  CheckCircle2,
  Music,
  Mic,
  Sliders,
  Radio,
  BookOpen,
} from "lucide-react";
import { Tradition, RegionalLanguageOption, RegionalNarrationData } from "../types";
import { voiceService } from "../services/voiceService";

interface RegionalNarrationPlayerProps {
  tradition: Tradition;
  initialLanguage?: string;
  compact?: boolean;
}

// 3 Major Audio Language Modes requested by user:
// 1. Hindi (हिन्दी)
// 2. Regional Language (Bhojpuri, Kashmiri, Nagpuri, Maithili, Awadhi, Bengali)
// 3. English
type LanguageMode = "hindi" | "regional" | "english";

const REGIONAL_DIALECTS: RegionalLanguageOption[] = [
  { id: "bhojpuri", name: "Bhojpuri", nativeName: "भोजपुरी", flag: "🌾", description: "भोजपुरिया लोक-कंठ (बिहार / पूर्वी उप)" },
  { id: "kashmiri", name: "Kashmiri", nativeName: "कॉशुर (كٲशُر)", flag: "🏔️", description: "कश्मीरी वादीक बोली (कश्मीर घाटी)" },
  { id: "nagpuri", name: "Nagpuri", nativeName: "नागपुरी / सादरी", flag: "🌿", description: "छोटानागपुरिया सादरी (झारखंड)" },
  { id: "maithili", name: "Maithili", nativeName: "मैथिली", flag: "📜", description: "मिथिलांचल भाषा (जनकपुर / तिरहुत)" },
  { id: "awadhi", name: "Awadhi", nativeName: "अवधी", flag: "🪔", description: "अवध लोक शैली (अयोध्या / अवध)" },
  { id: "bengali", name: "Bengali", nativeName: "বাংলা", flag: "🌊", description: "ঐতিহ্যবাহী বাংলা (পশ্চিমবঙ্গ)" },
];

export const RegionalNarrationPlayer: React.FC<RegionalNarrationPlayerProps> = ({
  tradition,
  initialLanguage,
  compact = false,
}) => {
  // Determine smart dialect matching the tradition's authentic heritage
  const detectAuthenticDialect = (): string => {
    const textAndLang = `${tradition.language || ""} ${tradition.region || ""} ${tradition.title}`.toLowerCase();
    if (textAndLang.includes("kashmir") || textAndLang.includes("rouf") || textAndLang.includes("koshur")) return "kashmiri";
    if (textAndLang.includes("nagpur") || textAndLang.includes("sadri") || textAndLang.includes("jharkhand") || textAndLang.includes("karma") || textAndLang.includes("jitiya")) return "nagpuri";
    if (textAndLang.includes("maithil") || textAndLang.includes("mithila") || textAndLang.includes("madhubani")) return "maithili";
    if (textAndLang.includes("awadh") || textAndLang.includes("sohar") || textAndLang.includes("birha")) return "awadhi";
    if (textAndLang.includes("bengal") || textAndLang.includes("baul") || textAndLang.includes("durga") || textAndLang.includes("bangla")) return "bengali";
    return "bhojpuri"; // Default authentic folk dialect for Chhath & Eastern plains
  };

  // State: 3 primary language modes
  const [languageMode, setLanguageMode] = useState<LanguageMode>(() => {
    if (initialLanguage === "english") return "english";
    if (initialLanguage === "hindi") return "hindi";
    if (initialLanguage) return "regional";
    return "hindi";
  });

  const [selectedRegionalDialect, setSelectedRegionalDialect] = useState<string>(detectAuthenticDialect());

  // Effective language sent to API / Voice Engine
  const effectiveLang = languageMode === "hindi" ? "hindi" : languageMode === "english" ? "english" : selectedRegionalDialect;

  const [narrationData, setNarrationData] = useState<RegionalNarrationData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Audio Playback Engine: "humanVoice" (Natural SpeechSynthesis + Pacing) vs "studioMaster" (Gemini / Server WAV)
  const [voiceEngine, setVoiceEngine] = useState<"humanVoice" | "studioMaster">("humanVoice");
  const [tanpuraWarmth, setTanpuraWarmth] = useState<boolean>(voiceService.isTanpuraActive());
  const [oralPacing, setOralPacing] = useState<number>(0.92); // 0.92 for warm, human storytelling tempo

  // Audio state
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isAudioLoading, setIsAudioLoading] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [activePart, setActivePart] = useState<"all" | "caption" | "description">("all");
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Fetch narration data whenever effective language or tradition changes
  useEffect(() => {
    let isCancelled = false;

    async function fetchNarration() {
      setIsLoading(true);
      setFetchError(null);
      stopAllAudio();

      try {
        const url = `/api/voice/regional-narration?id=${encodeURIComponent(tradition.id)}&lang=${encodeURIComponent(effectiveLang)}`;
        const res = await fetch(url);
        if (!res.ok) {
          throw new Error(`Failed to load regional narration (${res.status})`);
        }
        const json = await res.json();
        if (!isCancelled && json.success) {
          setNarrationData(json);
        }
      } catch (err: any) {
        if (!isCancelled) {
          console.error("Regional narration fetch error:", err);
          setFetchError(err.message || "Failed to fetch regional translation");
        }
      } finally {
        if (!isCancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchNarration();

    return () => {
      isCancelled = true;
    };
  }, [tradition.id, effectiveLang]);

  // Audio setup and event listeners for studio master stream
  useEffect(() => {
    const audio = new Audio();
    audioRef.current = audio;

    const handlePlay = () => {
      setIsPlaying(true);
      setIsAudioLoading(false);
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    const handleWaiting = () => {
      setIsAudioLoading(true);
    };

    const handleCanPlay = () => {
      setIsAudioLoading(false);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }
      setIsAudioLoading(false);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    const handleError = () => {
      setIsPlaying(false);
      setIsAudioLoading(false);
    };

    audio.addEventListener("play", handlePlay);
    audio.addEventListener("pause", handlePause);
    audio.addEventListener("waiting", handleWaiting);
    audio.addEventListener("canplay", handleCanPlay);
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("error", handleError);

    return () => {
      audio.pause();
      audio.removeEventListener("play", handlePlay);
      audio.removeEventListener("pause", handlePause);
      audio.removeEventListener("waiting", handleWaiting);
      audio.removeEventListener("canplay", handleCanPlay);
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("error", handleError);
    };
  }, []);

  const stopAllAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(false);
  };

  const handlePlayPart = (part: "all" | "caption" | "description") => {
    if (!narrationData) return;

    // Toggle pause if currently playing this exact part
    if (activePart === part && isPlaying) {
      stopAllAudio();
      return;
    }

    stopAllAudio();
    setActivePart(part);

    let textToSpeak = narrationData.fullText;
    if (part === "caption") {
      textToSpeak = narrationData.caption;
    } else if (part === "description") {
      textToSpeak = narrationData.description;
    }

    if (voiceEngine === "humanVoice") {
      // Human Storyteller Engine with natural prosody and authentic pauses
      setIsAudioLoading(false);
      setIsPlaying(true);
      voiceService
        .playHumanNarration(
          textToSpeak,
          effectiveLang,
          tradition.id,
          tradition.title,
          part,
          oralPacing
        )
        .then(() => {
          setIsPlaying(false);
        })
        .catch((err) => {
          console.warn("Human speech synthesis notice:", err);
          setIsPlaying(false);
        });
    } else {
      // Studio Master Stream from Gemini / Server Audio
      if (!audioRef.current) return;
      const targetUrl = narrationData.audioUrls[part];
      setIsAudioLoading(true);
      audioRef.current.src = targetUrl;
      audioRef.current.playbackRate = oralPacing;
      audioRef.current.muted = isMuted;
      audioRef.current.load();

      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
          setIsAudioLoading(false);
        })
        .catch((err) => {
          console.warn("Server audio playback error, falling back to human voice:", err);
          setIsAudioLoading(false);
          // Seamless fallback to human voice
          voiceService.playHumanNarration(
            textToSpeak,
            effectiveLang,
            tradition.id,
            tradition.title,
            part,
            oralPacing
          );
        });
    }
  };

  const handleToggleTanpura = () => {
    voiceService.toggleTanpuraWarmth();
    setTanpuraWarmth(voiceService.isTanpuraActive());
  };

  const handlePacingChange = (speed: number) => {
    setOralPacing(speed);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
    // If currently speaking in human voice, restart seamlessly with new pacing
    if (isPlaying && voiceEngine === "humanVoice") {
      handlePlayPart(activePart);
    }
  };

  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (audioRef.current) {
      audioRef.current.muted = nextMuted;
    }
  };

  const handleRestart = () => {
    handlePlayPart(activePart);
  };

  const handleCopyText = () => {
    if (!narrationData) return;
    const textToCopy = `[${narrationData.language} - ${narrationData.nativeName}]\n${tradition.title}\n\n[Caption / सारांश]:\n${narrationData.caption}\n\n[Description / कथा]:\n${narrationData.description}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  const activeRegionalDialectObj =
    REGIONAL_DIALECTS.find((d) => d.id === selectedRegionalDialect) || REGIONAL_DIALECTS[0];

  return (
    <div className="bg-[#FAF7F2] border border-[#E5DDD0] rounded-xl p-5 shadow-xs transition-all">
      {/* Header with Title & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3.5 border-b border-[#E8DFD1]">
        <div>
          <div className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
            <Headphones size={15} className="text-[#A64B2A]" />
            <span>Voice & Language Selector (भाषा व बोली में सुनें)</span>
          </div>
          <p className="text-xs text-[#6B655B] mt-0.5">
            Choose to listen in Hindi, Regional dialect, or English with a warm, natural human touch.
          </p>
        </div>

        {/* Copy Citation/Text */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleCopyText}
            disabled={!narrationData || isLoading}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-[#1B4332] bg-white border border-[#D5C9B7] rounded-md hover:bg-[#EFE9DF] transition-colors cursor-pointer disabled:opacity-50"
            title="Copy current language text"
          >
            {copied ? <Check size={12} className="text-emerald-700" /> : <Copy size={12} />}
            <span>{copied ? "Copied" : "Copy Spoken Text"}</span>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3 EXPLICIT LANGUAGE MODE SELECTION (Hindi, Regional, English) */}
      {/* ============================================================ */}
      <div className="mt-4">
        <label className="text-[11px] font-semibold text-[#8B8477] uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Globe2 size={13} className="text-[#1B4332]" />
          <span>Select Listening Language (भाषा का चयन करें):</span>
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {/* Mode 1: Hindi */}
          <button
            type="button"
            onClick={() => setLanguageMode("hindi")}
            className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
              languageMode === "hindi"
                ? "bg-[#1B4332] text-white border-[#1B4332] shadow-sm ring-2 ring-[#1B4332]/20"
                : "bg-white border-[#D5C9B7] text-[#22201D] hover:bg-[#F5EFE6] hover:border-[#1B4332]"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-2xl leading-none">🇮🇳</span>
              <div>
                <div className="font-serif font-bold text-sm">हिन्दी (Hindi)</div>
                <div className={`text-[11px] ${languageMode === "hindi" ? "text-emerald-100" : "text-[#7C7467]"}`}>
                  मानक देवनागरी वाचिक स्वर
                </div>
              </div>
            </div>
            {languageMode === "hindi" && <CheckCircle2 size={16} className="text-emerald-300" />}
          </button>

          {/* Mode 2: Regional Language */}
          <button
            type="button"
            onClick={() => setLanguageMode("regional")}
            className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
              languageMode === "regional"
                ? "bg-[#A64B2A] text-white border-[#A64B2A] shadow-sm ring-2 ring-[#A64B2A]/20"
                : "bg-white border-[#D5C9B7] text-[#22201D] hover:bg-[#F5EFE6] hover:border-[#A64B2A]"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-2xl leading-none">{activeRegionalDialectObj.flag}</span>
              <div>
                <div className="font-serif font-bold text-sm">
                  क्षेत्रीय बोली (Regional)
                </div>
                <div className={`text-[11px] ${languageMode === "regional" ? "text-amber-100" : "text-[#7C7467]"}`}>
                  {activeRegionalDialectObj.nativeName} ({activeRegionalDialectObj.name})
                </div>
              </div>
            </div>
            {languageMode === "regional" && <CheckCircle2 size={16} className="text-amber-200" />}
          </button>

          {/* Mode 3: English */}
          <button
            type="button"
            onClick={() => setLanguageMode("english")}
            className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all cursor-pointer ${
              languageMode === "english"
                ? "bg-[#1B4332] text-white border-[#1B4332] shadow-sm ring-2 ring-[#1B4332]/20"
                : "bg-white border-[#D5C9B7] text-[#22201D] hover:bg-[#F5EFE6] hover:border-[#1B4332]"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-2xl leading-none">🌐</span>
              <div>
                <div className="font-serif font-bold text-sm">English</div>
                <div className={`text-[11px] ${languageMode === "english" ? "text-emerald-100" : "text-[#7C7467]"}`}>
                  Scholarly Archival Narration
                </div>
              </div>
            </div>
            {languageMode === "english" && <CheckCircle2 size={16} className="text-emerald-300" />}
          </button>
        </div>

        {/* Sub-Selector: Regional Dialects (Only visible when "Regional" mode is selected) */}
        {languageMode === "regional" && (
          <div className="mt-3 p-3 bg-[#F4EDE2] border border-[#DFCFC0] rounded-xl animate-fade-in">
            <div className="text-[11px] font-semibold text-[#8B4513] uppercase tracking-wider mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Sliders size={12} />
                <span>Select Regional Dialect (विशिष्ट क्षेत्रीय बोली चुनें):</span>
              </span>
              <span className="text-[10px] text-[#8B8477] font-normal">
                Authentic folk expressions & idioms
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
              {REGIONAL_DIALECTS.map((dialect) => {
                const isSelected = selectedRegionalDialect === dialect.id;
                const isAuthentic = dialect.id === detectAuthenticDialect();
                return (
                  <button
                    key={dialect.id}
                    type="button"
                    onClick={() => setSelectedRegionalDialect(dialect.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all shrink-0 cursor-pointer select-none ${
                      isSelected
                        ? "bg-[#A64B2A] text-white shadow-xs font-semibold ring-2 ring-[#A64B2A]/30"
                        : "bg-white border border-[#D5C9B7] text-[#332E27] hover:bg-[#FAF7F2] hover:border-[#A64B2A]"
                    }`}
                    title={dialect.description}
                  >
                    <span>{dialect.flag}</span>
                    <span className="font-serif font-semibold">{dialect.nativeName}</span>
                    <span className={`text-[10px] ${isSelected ? "text-white/80" : "text-[#8B8477]"}`}>
                      ({dialect.name})
                    </span>
                    {isAuthentic && (
                      <span className="px-1 py-0.2 bg-amber-100 text-amber-900 text-[9px] rounded font-bold uppercase ml-0.5">
                        Native
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* HUMAN TOUCH & AUDIO QUALITY BAR */}
      {/* ============================================================ */}
      <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2.5 p-2.5 bg-white border border-[#E5DDD0] rounded-lg">
        {/* Voice Style Engine */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-[#8B8477] uppercase tracking-wider flex items-center gap-1">
            <Mic size={12} className="text-[#A64B2A]" />
            <span>Voice Style:</span>
          </span>
          <div className="inline-flex rounded-md border border-[#D5C9B7] p-0.5 bg-[#FAF7F2]">
            <button
              type="button"
              onClick={() => {
                setVoiceEngine("humanVoice");
                stopAllAudio();
              }}
              className={`px-2 py-0.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                voiceEngine === "humanVoice"
                  ? "bg-[#1B4332] text-white font-semibold shadow-2xs"
                  : "text-[#6B655B] hover:text-[#1B4332]"
              }`}
              title="Warm human oral storyteller cadence with natural pauses"
            >
              🗣️ Human Storyteller
            </button>
            <button
              type="button"
              onClick={() => {
                setVoiceEngine("studioMaster");
                stopAllAudio();
              }}
              className={`px-2 py-0.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                voiceEngine === "studioMaster"
                  ? "bg-[#1B4332] text-white font-semibold shadow-2xs"
                  : "text-[#6B655B] hover:text-[#1B4332]"
              }`}
              title="Gemini AI studio audio stream"
            >
              ✨ Studio Master
            </button>
          </div>
        </div>

        {/* Storyteller Pacing (Oral Cadence) */}
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-semibold text-[#8B8477] uppercase tracking-wider">
            Cadence:
          </span>
          <div className="flex items-center gap-1">
            {[
              { speed: 0.88, label: "0.9x Storyteller", title: "Relaxed, reverent oral tempo" },
              { speed: 1.0, label: "1.0x Natural", title: "Normal conversation tempo" },
              { speed: 1.15, label: "1.15x Lively", title: "Swift overview tempo" },
            ].map((p) => (
              <button
                key={p.speed}
                type="button"
                onClick={() => handlePacingChange(p.speed)}
                className={`px-2 py-0.5 text-[11px] rounded transition-colors cursor-pointer ${
                  oralPacing === p.speed
                    ? "bg-[#EFE9DF] text-[#1B4332] font-bold border border-[#D5C9B7]"
                    : "text-[#6B655B] hover:bg-[#FAF7F2]"
                }`}
                title={p.title}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tanpura Acoustic Warmth Toggle */}
        <button
          type="button"
          onClick={handleToggleTanpura}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-all cursor-pointer ${
            tanpuraWarmth
              ? "bg-[#F7E7CE] text-[#8B4513] border border-[#E3B873] font-semibold shadow-2xs"
              : "bg-[#FAF7F2] border border-[#D5C9B7] text-[#6B655B] hover:bg-[#EFE9DF]"
          }`}
          title="Toggle acoustic Tanpura drone bed for an intimate hearth storytelling atmosphere"
        >
          <Music size={12} className={tanpuraWarmth ? "text-[#8B4513]" : "text-[#8B8477]"} />
          <span>तंबूरा स्वर संगत (Tanpura Warmth)</span>
          <span
            className={`w-1.5 h-1.5 rounded-full ${tanpuraWarmth ? "bg-amber-600 animate-pulse" : "bg-stone-300"}`}
          />
        </button>
      </div>

      {/* ============================================================ */}
      {/* MAIN CONTENT AREA */}
      {/* ============================================================ */}
      {isLoading ? (
        <div className="py-12 text-center">
          <Loader2 size={26} className="animate-spin text-[#1B4332] mx-auto mb-2.5" />
          <p className="text-xs font-medium text-[#6B655B]">
            Preparing authentic voice and localized text in{" "}
            {languageMode === "hindi"
              ? "Hindi (हिन्दी)"
              : languageMode === "english"
              ? "English"
              : `${activeRegionalDialectObj.name} (${activeRegionalDialectObj.nativeName})`}
            ...
          </p>
        </div>
      ) : fetchError ? (
        <div className="mt-4 p-4 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
          <p className="font-medium">Audio Generation Notice</p>
          <p className="mt-0.5">{fetchError}</p>
          <button
            onClick={() => setLanguageMode("hindi")}
            className="mt-2 px-2.5 py-1 bg-white border border-rose-300 rounded text-rose-900 font-medium hover:bg-rose-100 cursor-pointer"
          >
            Switch to Hindi
          </button>
        </div>
      ) : narrationData ? (
        <div className="mt-4 space-y-4">
          {/* Master Audio Controller Card */}
          <div className="bg-white border border-[#E5DDD0] rounded-xl p-4 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-[#F0EAE1]">
              <div className="flex items-center gap-3">
                {/* Big Master Play Button */}
                <button
                  type="button"
                  onClick={() => handlePlayPart("all")}
                  disabled={isAudioLoading}
                  className={`flex items-center justify-center w-12 h-12 rounded-full transition-all cursor-pointer shadow-xs ${
                    activePart === "all" && isPlaying
                      ? "bg-[#A64B2A] text-white ring-4 ring-[#A64B2A]/20 scale-105"
                      : "bg-[#1B4332] hover:bg-[#2D6A4F] text-white hover:scale-105"
                  }`}
                  title={
                    isPlaying && activePart === "all"
                      ? "Pause Full Narration"
                      : "Listen to Full Narration (Caption + Story)"
                  }
                >
                  {isAudioLoading && activePart === "all" ? (
                    <Loader2 size={20} className="animate-spin" />
                  ) : activePart === "all" && isPlaying ? (
                    <Pause size={20} className="fill-current" />
                  ) : (
                    <Play size={20} className="fill-current ml-0.5" />
                  )}
                </button>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-serif font-bold text-[#1B4332]">
                      {activePart === "all"
                        ? "Full Narration (संपूर्ण कथा)"
                        : activePart === "caption"
                        ? "Caption Audio (संक्षेप सारांश)"
                        : "Description Audio (विस्तृत विवरण)"}
                    </span>
                    <span className="px-2 py-0.5 bg-[#FAF7F2] border border-[#E5DDD0] rounded text-[11px] text-[#A64B2A] font-semibold">
                      {narrationData.flag} {narrationData.nativeName}
                    </span>
                  </div>
                  <p className="text-xs text-[#6B655B] mt-0.5 flex items-center gap-1.5">
                    {isPlaying ? (
                      <span className="text-emerald-700 font-medium flex items-center gap-1">
                        <Radio size={12} className="animate-pulse" />
                        Speaking now with human oral cadence...
                      </span>
                    ) : (
                      "Click play to listen to caption and oral history"
                    )}
                  </p>
                </div>
              </div>

              {/* Sub-Part Quick Listen Buttons */}
              <div className="flex items-center flex-wrap gap-1.5">
                <span className="text-[11px] text-[#8B8477] font-medium mr-1">Listen Part:</span>
                <button
                  type="button"
                  onClick={() => handlePlayPart("caption")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                    activePart === "caption" && isPlaying
                      ? "bg-[#1B4332] text-white font-semibold shadow-xs"
                      : "bg-[#FAF7F2] border border-[#D5C9B7] text-[#332E27] hover:bg-[#EFE9DF]"
                  }`}
                >
                  {activePart === "caption" && isPlaying ? (
                    <Pause size={12} className="fill-current" />
                  ) : (
                    <Play size={12} className="fill-[#A64B2A] text-[#A64B2A]" />
                  )}
                  <span>Caption Only</span>
                </button>

                <button
                  type="button"
                  onClick={() => handlePlayPart("description")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                    activePart === "description" && isPlaying
                      ? "bg-[#1B4332] text-white font-semibold shadow-xs"
                      : "bg-[#FAF7F2] border border-[#D5C9B7] text-[#332E27] hover:bg-[#EFE9DF]"
                  }`}
                >
                  {activePart === "description" && isPlaying ? (
                    <Pause size={12} className="fill-current" />
                  ) : (
                    <Play size={12} className="fill-[#A64B2A] text-[#A64B2A]" />
                  )}
                  <span>Story Only</span>
                </button>

                <button
                  type="button"
                  onClick={() => handlePlayPart("all")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                    activePart === "all" && isPlaying
                      ? "bg-[#1B4332] text-white font-semibold shadow-xs"
                      : "bg-[#FAF7F2] border border-[#D5C9B7] text-[#332E27] hover:bg-[#EFE9DF]"
                  }`}
                >
                  {activePart === "all" && isPlaying ? (
                    <Pause size={12} className="fill-current" />
                  ) : (
                    <Play size={12} className="fill-[#A64B2A] text-[#A64B2A]" />
                  )}
                  <span>Both</span>
                </button>
              </div>
            </div>

            {/* Scrubber & Audio Controls */}
            <div className="mt-3 pt-2">
              <div className="flex items-center gap-3">
                <span className="text-[11px] tabular-nums font-mono text-[#6B655B] w-8">
                  {formatTime(currentTime)}
                </span>
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  step="0.1"
                  value={currentTime}
                  onChange={(e) => {
                    const newTime = parseFloat(e.target.value);
                    setCurrentTime(newTime);
                    if (audioRef.current) audioRef.current.currentTime = newTime;
                  }}
                  className="flex-1 h-1.5 bg-[#E5DDD0] rounded-lg appearance-none cursor-pointer accent-[#1B4332]"
                  aria-label="Seek audio progress"
                />
                <span className="text-[11px] tabular-nums font-mono text-[#6B655B] w-8">
                  {formatTime(duration)}
                </span>

                {/* Restart */}
                <button
                  type="button"
                  onClick={handleRestart}
                  className="p-1 text-[#6B655B] hover:text-[#1B4332] hover:bg-[#FAF7F2] rounded cursor-pointer transition-colors"
                  title="Replay from beginning"
                >
                  <RotateCcw size={14} />
                </button>

                {/* Mute */}
                <button
                  type="button"
                  onClick={handleToggleMute}
                  className="p-1 text-[#6B655B] hover:text-[#1B4332] hover:bg-[#FAF7F2] rounded cursor-pointer transition-colors"
                  title={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                </button>
              </div>

              {/* Live Breathing Soundwave Visualizer */}
              {isPlaying && (
                <div className="mt-2.5 flex items-center justify-center gap-1.5 py-1 bg-[#FAF8F5] rounded-lg">
                  <span className="w-1 h-2 bg-[#1B4332] rounded-full animate-pulse" />
                  <span
                    className="w-1 h-4 bg-[#A64B2A] rounded-full animate-pulse"
                    style={{ animationDelay: "120ms" }}
                  />
                  <span
                    className="w-1 h-3 bg-[#1B4332] rounded-full animate-pulse"
                    style={{ animationDelay: "240ms" }}
                  />
                  <span
                    className="w-1 h-5 bg-[#A64B2A] rounded-full animate-pulse"
                    style={{ animationDelay: "360ms" }}
                  />
                  <span
                    className="w-1 h-3 bg-[#1B4332] rounded-full animate-pulse"
                    style={{ animationDelay: "480ms" }}
                  />
                  <span
                    className="w-1 h-2 bg-[#1B4332] rounded-full animate-pulse"
                    style={{ animationDelay: "600ms" }}
                  />
                  <span className="text-[11px] font-serif text-[#1B4332] ml-2 font-medium">
                    Listening in {narrationData.nativeName} ({narrationData.language})
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Section 1: Localized Caption Card */}
          <div
            className={`border rounded-xl p-4.5 transition-all ${
              activePart === "caption" && isPlaying
                ? "bg-[#FFFDF9] border-[#A64B2A] shadow-md ring-2 ring-[#A64B2A]/10"
                : "bg-white border-[#E5DDD0]"
            }`}
          >
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#F0EAE1]">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-[#FAF7F2] border border-[#E5DDD0] rounded text-[11px] font-semibold text-[#A64B2A] uppercase tracking-wider">
                  {narrationData.nativeName} संक्षेप (Caption)
                </span>
                <span className="text-[11px] text-[#8B8477]">
                  Oral Takeaway & Core Essence
                </span>
              </div>
              <button
                type="button"
                onClick={() => handlePlayPart("caption")}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] text-[#1B4332] rounded-full text-xs font-medium transition-colors cursor-pointer"
                title="Listen specifically to the caption"
              >
                {activePart === "caption" && isPlaying ? (
                  <>
                    <Pause size={11} className="fill-current" />
                    <span>Pause Caption</span>
                  </>
                ) : (
                  <>
                    <Play size={11} className="fill-[#A64B2A] text-[#A64B2A]" />
                    <span>Listen Caption</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-base font-serif text-[#22201D] leading-relaxed font-medium">
              {narrationData.caption}
            </p>
          </div>

          {/* Section 2: Localized Description Card */}
          <div
            className={`border rounded-xl p-4.5 transition-all ${
              activePart === "description" && isPlaying
                ? "bg-[#FFFDF9] border-[#1B4332] shadow-md ring-2 ring-[#1B4332]/10"
                : "bg-white border-[#E5DDD0]"
            }`}
          >
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#F0EAE1]">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-[#FAF7F2] border border-[#E5DDD0] rounded text-[11px] font-semibold text-[#1B4332] uppercase tracking-wider">
                  {narrationData.nativeName} विस्तृत लोक कथा (Description)
                </span>
                <span className="text-[11px] text-[#8B8477]">
                  Living Oral Narrative & Vernacular Nuance
                </span>
              </div>
              <button
                type="button"
                onClick={() => handlePlayPart("description")}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#FAF7F2] hover:bg-[#EFE9DF] border border-[#D5C9B7] text-[#1B4332] rounded-full text-xs font-medium transition-colors cursor-pointer"
                title="Listen specifically to the description"
              >
                {activePart === "description" && isPlaying ? (
                  <>
                    <Pause size={11} className="fill-current" />
                    <span>Pause Story</span>
                  </>
                ) : (
                  <>
                    <Play size={11} className="fill-[#A64B2A] text-[#A64B2A]" />
                    <span>Listen Description</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-sm font-serif text-[#332E27] leading-relaxed whitespace-pre-wrap">
              {narrationData.description}
            </p>
          </div>
        </div>
      ) : null}
    </div>
  );
};
