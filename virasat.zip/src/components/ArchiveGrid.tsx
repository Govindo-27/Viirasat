import React from "react";
import { Search, Globe, Filter, Sparkles, BookOpen, Download, Radio, Volume2, Headphones } from "lucide-react";
import { Tradition, HeritageCategory } from "../types";
import { AudioPlayer } from "./AudioPlayer";
import { TraditionPlaybackButton } from "./TraditionPlaybackButton";

interface ArchiveGridProps {
  traditions: Tradition[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: HeritageCategory;
  onCategoryChange: (category: HeritageCategory) => void;
  selectedLanguage: string;
  onLanguageChange: (language: string) => void;
  onSelectTradition: (tradition: Tradition) => void;
  isLoading: boolean;
}

const CATEGORIES: HeritageCategory[] = [
  "All",
  "Festivals",
  "Music & Performing Arts",
  "Recipes",
  "Oral Histories",
  "Folk Practices",
  "Traditional Crafts",
  "Stories",
];

const COMMON_LANGUAGES = [
  "All",
  "Hindi",
  "Bhojpuri",
  "Kashmiri",
  "Nagpuri",
  "English",
  "Maithili",
  "Awadhi",
  "Bengali",
  "Gujarati",
  "Marathi",
  "Punjabi",
  "Tamil",
];

export const ArchiveGrid: React.FC<ArchiveGridProps> = ({
  traditions,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  selectedLanguage,
  onLanguageChange,
  onSelectTradition,
  isLoading,
}) => {
  const handleDirectExport = () => {
    const dataStr = JSON.stringify(traditions, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "virasat-cultural-archive.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-[#E5DDD0]">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
            Archive Catalog
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#1B4332] mt-0.5">
            Preserved Cultural Traditions
          </h2>
        </div>
        <div className="flex items-center gap-4 text-xs text-[#6B655B]">
          <span className="tabular-nums font-medium">
            <strong className="text-[#1B4332]">{traditions.length}</strong> records
          </span>
          <button
            onClick={handleDirectExport}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs text-[#1B4332] hover:bg-[#EFE9DF] border border-[#D5C9B7] rounded-md transition-colors cursor-pointer"
            title="Download full JSON dataset"
          >
            <Download size={13} />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Regional Voice Feature Banner */}
      <div className="mt-4 p-3 bg-gradient-to-r from-[#FAF7F2] via-white to-[#FAF7F2] border border-[#E5DDD0] rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <span className="p-1.5 bg-[#1B4332] text-white rounded-md shrink-0 shadow-xs">
            <Headphones size={14} />
          </span>
          <div>
            <span className="font-semibold text-[#1B4332]">Listen in Regional Languages:</span>
            <span className="text-[#554F45] ml-1.5">
              Oral caption and detailed description audio are available in <strong>हिन्दी (Hindi)</strong>, <strong>भोजपुरी (Bhojpuri)</strong>, <strong>कॉशुर (Kashmiri)</strong>, <strong>नागपुरी / सादरी (Nagpuri)</strong>, <strong>English</strong>, मैथिली, and अवधी.
            </span>
          </div>
        </div>
        <span className="text-[11px] text-[#A64B2A] font-semibold flex items-center gap-1 shrink-0">
          <span>Select any card to listen</span>
          <span aria-hidden="true">→</span>
        </span>
      </div>

      {/* Search and Filters Toolbar */}
      <div className="mt-5 space-y-3.5">
        {/* Search Input Bar */}
        <div className="relative">
          <Search
            size={17}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8B8477] pointer-events-none"
          />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search traditions by keyword, region, craft, recipe, or dialect..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-[#D5C9B7] rounded-md text-sm text-[#22201D] placeholder:text-[#8B8477] focus:outline-none focus:ring-1 focus:ring-[#1B4332] focus:border-[#1B4332] transition-colors"
          />
        </div>

        {/* Filter Controls Row */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-1">
          {/* Category Filter - Segmented Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-none">
            <span className="text-xs font-medium text-[#6B655B] shrink-0 mr-1 flex items-center gap-1">
              <Filter size={12} />
              Domain:
            </span>
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => onCategoryChange(cat)}
                className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? "bg-[#1B4332] text-white shadow-xs font-semibold"
                    : "bg-[#EFE9DF] text-[#554F45] hover:bg-[#E5DDD0] hover:text-[#1B4332]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Language Selector */}
          <div className="flex items-center gap-2 self-start lg:self-auto shrink-0">
            <Globe size={13} className="text-[#8B8477]" />
            <label htmlFor="language-select" className="text-xs font-medium text-[#6B655B]">
              Language:
            </label>
            <select
              id="language-select"
              value={selectedLanguage}
              onChange={(e) => onLanguageChange(e.target.value)}
              className="bg-white border border-[#D5C9B7] text-xs font-medium text-[#22201D] rounded-md px-2.5 py-1 focus:outline-none focus:ring-1 focus:ring-[#1B4332] cursor-pointer"
            >
              {COMMON_LANGUAGES.map((lang) => (
                <option key={lang} value={lang}>
                  {lang === "All" ? "All Languages" : lang}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="mt-6">
        {isLoading ? (
          <div className="py-16 text-center">
            <div className="inline-block w-7 h-7 border-2 border-[#1B4332] border-t-transparent rounded-full animate-spin mb-2" />
            <p className="text-xs font-medium text-[#6B655B]">Loading archive catalog...</p>
          </div>
        ) : traditions.length === 0 ? (
          <div className="py-12 text-center bg-white border border-[#E5DDD0] rounded-lg p-6">
            <BookOpen size={32} className="mx-auto text-[#A64B2A] stroke-1 mb-2" />
            <h3 className="text-base font-serif font-bold text-[#1B4332]">No matching traditions found</h3>
            <p className="text-xs text-[#6B655B] max-w-md mx-auto mt-1 mb-3">
              Try adjusting your search terms or filters.
            </p>
            <button
              onClick={() => {
                onSearchChange("");
                onCategoryChange("All");
                onLanguageChange("All");
              }}
              className="px-3.5 py-1.5 text-xs font-medium text-[#1B4332] bg-[#EFE9DF] hover:bg-[#E5DDD0] rounded-md transition-colors cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {traditions.map((tradition, index) => (
              <article
                key={tradition.id}
                onClick={() => onSelectTradition(tradition)}
                style={{ animationDelay: `${index * 60}ms` }}
                className="heritage-card animate-fade-in bg-white/95 backdrop-blur-2xs border border-[#E5DDD0] hover:border-[#1B4332] rounded-lg p-5 flex flex-col justify-between cursor-pointer text-left transition-all"
              >
                <div>
                  {/* Clean unboxed metadata with dot separators */}
                  <div className="flex items-center flex-wrap gap-x-2 text-xs text-[#8B8477] font-medium mb-2">
                    <span className="text-[#A64B2A] font-semibold">{tradition.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{tradition.language}</span>
                    <span aria-hidden="true">·</span>
                    <span>{tradition.region}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums font-mono text-[11px] text-[#A64B2A]/80">
                      #{tradition.id}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-serif font-bold text-[#1B4332] group-hover:text-[#2D6A4F] transition-colors leading-snug">
                    {tradition.title}
                  </h3>

                  {/* Compact Audio Preview Badge if available */}
                  {tradition.audioSource && (
                    <div className="mt-3">
                      <AudioPlayer audioSource={tradition.audioSource} compact={true} />
                    </div>
                  )}

                  {/* AI Curated Summary */}
                  {tradition.curatorNotes?.summary && (
                    <div className="mt-3 pt-3 border-t border-[#F0EAE1]">
                      <div className="flex items-center gap-1 text-[11px] uppercase tracking-wider text-[#A64B2A] font-semibold mb-1">
                        <Sparkles size={11} />
                        <span>Curator Synopsis</span>
                      </div>
                      <p className="text-xs text-[#443E36] leading-relaxed line-clamp-3">
                        {tradition.curatorNotes.summary}
                      </p>
                    </div>
                  )}

                  {/* Original Text Excerpt */}
                  <div className="mt-2.5 pt-2.5 border-t border-[#F0EAE1]">
                    <p className="text-xs text-[#6B655B] italic leading-relaxed line-clamp-2">
                      "{tradition.originalText}"
                    </p>
                  </div>

                  {/* Regional Tongue Voice Pill */}
                  <div className="mt-2.5 pt-1.5 flex items-center justify-between text-[11px] text-[#1B4332] bg-[#FAF7F2] px-2.5 py-1.5 rounded-md border border-[#E8DFD1]">
                    <span className="inline-flex items-center gap-1.5 font-serif text-[#A64B2A] font-medium">
                      <Headphones size={11} />
                      <span>Regional Voice (हिन्दी, भोजपुरी, कॉशुर, नागपुरी, En)</span>
                    </span>
                    <span className="text-[10px] text-[#1B4332] font-semibold group-hover:underline">
                      Listen & Read →
                    </span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F0EAE1]">
                  <div className="flex items-center justify-between gap-2">
                    {/* High-Quality AI Voice Narration Button */}
                    <TraditionPlaybackButton
                      tradition={tradition}
                      size="sm"
                      showVoiceSelector={true}
                    />

                    <div className="flex items-center gap-2">
                      {tradition.audioSource && (
                        <span
                          className="hidden sm:inline-flex items-center gap-1 text-[11px] text-[#A64B2A] font-medium"
                          title="Original field recording linked from YouTube/Spotify"
                        >
                          <Radio size={11} />
                          <span>Field Audio</span>
                        </span>
                      )}
                      <div className="text-xs text-[#1B4332] font-semibold group-hover:underline flex items-center gap-0.5 shrink-0">
                        <span>Details</span>
                        <span aria-hidden="true">→</span>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
