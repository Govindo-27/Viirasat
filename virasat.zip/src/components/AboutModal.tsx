import React from "react";
import { X, Sparkles, BookOpen, Volume2, ShieldCheck, Heart } from "lucide-react";

interface AboutModalProps {
  onClose: () => void;
  traditionsCount: number;
}

export const AboutModal: React.FC<AboutModalProps> = ({ onClose, traditionsCount }) => {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="animate-modal-in relative bg-[#FAF7F2] border border-[#E5DDD0] w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl p-6 sm:p-8 text-left my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#E5DDD0]">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
              Archive Manifesto
            </span>
            <h3 className="text-2xl font-serif font-bold text-[#1B4332] mt-0.5">
              About Virasat
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B655B] hover:text-[#1B4332] rounded-md hover:bg-[#EFE9DF] transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tagline & Purpose */}
        <div className="mt-5 space-y-4 text-sm text-[#443E36] leading-relaxed">
          <div className="p-4 bg-white border border-[#E5DDD0] rounded-lg">
            <div className="text-lg font-serif italic text-[#1B4332] font-semibold mb-1">
              “Every tradition deserves a tomorrow.”
            </div>
            <p className="text-xs text-[#6B655B]">
              Virasat is a publicly accessible, AI-assisted cultural heritage repository. It safeguards
              endangered oral histories, vernacular recipes, village rituals, artisanal craft steps, and
              traditional ecology that risk fading away as elder generations pass.
            </p>
          </div>

          {/* Core Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-3.5 bg-white border border-[#E5DDD0] rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1B4332]">
                <BookOpen size={14} className="text-[#A64B2A]" />
                <span>Original Voice Preserved</span>
              </div>
              <p className="text-xs text-[#6B655B]">
                We archive stories verbatim in their native tongue or dialect. Indigenous words are never
                altered or replaced.
              </p>
            </div>

            <div className="p-3.5 bg-white border border-[#E5DDD0] rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1B4332]">
                <Sparkles size={14} className="text-[#A64B2A]" />
                <span>Instant Cloud AI Curator</span>
              </div>
              <p className="text-xs text-[#6B655B]">
                Zero local setup or terminal installation required. The AI curator generates scholarly
                synopses, tags, and faithful English translations instantly.
              </p>
            </div>

            <div className="p-3.5 bg-white border border-[#E5DDD0] rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1B4332]">
                <Volume2 size={14} className="text-[#A64B2A]" />
                <span>Oral Accessibility</span>
              </div>
              <p className="text-xs text-[#6B655B]">
                Oral traditions are meant to be heard. Every preserved record includes one-click
                audio playback so everyone can listen aloud.
              </p>
            </div>

            <div className="p-3.5 bg-white border border-[#E5DDD0] rounded-lg space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1B4332]">
                <ShieldCheck size={14} className="text-[#A64B2A]" />
                <span>Cultural Humility & Fair Use</span>
              </div>
              <p className="text-xs text-[#6B655B]">
                Submissions are preserved under community consent. Records are clearly labeled as
                unverified folk memories rather than academic certifications.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-4 border-t border-[#E5DDD0] flex items-center justify-between text-xs text-[#6B655B]">
          <div className="flex items-center gap-1">
            <Heart size={13} className="text-[#A64B2A]" />
            <span>Preserving {traditionsCount} cultural traditions</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#1B4332] text-white text-xs font-semibold rounded-md hover:bg-[#2D6A4F] transition-colors cursor-pointer"
          >
            Explore Archive
          </button>
        </div>
      </div>
    </div>
  );
};
