import React, { useState, useEffect } from "react";
import { X, Copy, Check, Sparkles, BookOpen, Globe, ShieldAlert, Radio, Headphones } from "lucide-react";
import { Tradition } from "../types";
import { AudioPlayer } from "./AudioPlayer";
import { TraditionPlaybackButton } from "./TraditionPlaybackButton";
import { RegionalNarrationPlayer } from "./RegionalNarrationPlayer";

interface TraditionDetailModalProps {
  tradition: Tradition | null;
  onClose: () => void;
}

export const TraditionDetailModal: React.FC<TraditionDetailModalProps> = ({
  tradition,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<"regional" | "sideBySide" | "original" | "translation">("regional");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  if (!tradition) return null;

  const handleCopyCitation = () => {
    const citation = `Virasat Cultural Heritage Archive. "${tradition.title}" [Accession #${tradition.id}]. Contributed by ${tradition.contributorName}, ${tradition.region}. Category: ${tradition.category}, Original Language: ${tradition.language}. Preserved on ${tradition.datePreserved}.`;
    navigator.clipboard.writeText(citation);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="animate-modal-in relative bg-[#FAF7F2] border border-[#E5DDD0] w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl p-6 sm:p-8 text-left my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Action Row */}
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#E5DDD0]">
          <div>
            <div className="flex items-center flex-wrap gap-2 text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
              <span>{tradition.category}</span>
              <span aria-hidden="true">·</span>
              <span>{tradition.language}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-stone-600">#{tradition.id}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#1B4332] mt-1.5 leading-snug">
              {tradition.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B655B] hover:text-[#1B4332] rounded-md hover:bg-[#EFE9DF] transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X size={22} />
          </button>
        </div>

        {/* Accession Metadata Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 text-xs border-b border-[#E5DDD0] text-[#554F45]">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-[#8B8477]">Origin / Region</div>
            <div className="font-semibold text-[#1B4332] mt-0.5">{tradition.region}</div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-[#8B8477]">Preserved By</div>
            <div className="font-semibold text-[#1B4332] mt-0.5">{tradition.contributorName}</div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-[#8B8477]">Date Preserved</div>
            <div className="font-semibold text-[#1B4332] mt-0.5 tabular-nums">
              {tradition.datePreserved}
            </div>
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-[#8B8477]">Verification Status</div>
            <div className="font-medium text-[#A64B2A] mt-0.5">Unverified Community Memory</div>
          </div>
        </div>

        {/* Unverified Disclaimer Banner */}
        <div className="mt-4 p-3 bg-[#F4EFE6] border border-[#E5DDD0] rounded-md flex items-start gap-2.5 text-xs text-[#6B655B]">
          <ShieldAlert size={16} className="text-[#A64B2A] shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-[#1B4332]">Archive Notice:</span> Community
            contributions are preserved verbatim to honor living tradition. Historical facts are not
            academically certified. AI-generated translations and annotations are provided as
            interpretive aides.
          </div>
        </div>

        {/* Curator Synopsis Box */}
        {tradition.curatorNotes?.summary && (
          <div className="mt-6 p-5 bg-white border border-[#E5DDD0] rounded-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 mb-2 border-b border-[#F0EAE1]">
              <div className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-[#A64B2A] font-semibold">
                <Sparkles size={13} />
                <span>AI Heritage Curator Synopsis</span>
              </div>
              <div className="flex items-center gap-2">
                <TraditionPlaybackButton
                  tradition={tradition}
                  size="sm"
                  showVoiceSelector={true}
                />
              </div>
            </div>
            <p className="text-sm text-[#332E27] leading-relaxed">
              {tradition.curatorNotes.summary}
            </p>
            {tradition.curatorNotes.tags && tradition.curatorNotes.tags.length > 0 && (
              <div className="mt-3 pt-3 border-t border-[#F0EAE1] flex flex-wrap gap-2 text-xs text-[#6B655B]">
                <span className="text-[#8B8477] font-medium">Curator Tags:</span>
                {tradition.curatorNotes.tags.map((tag) => (
                  <span
                    key={tag}
                    className="bg-[#FAF7F2] border border-[#E5DDD0] px-2 py-0.5 rounded text-[11px]"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Authentic Audio Recording Section */}
        <div className="mt-6">
          <div className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-[#1B4332] font-semibold mb-2">
            <Radio size={14} className="text-[#A64B2A]" />
            <span>Authentic Living Recording</span>
          </div>
          <AudioPlayer audioSource={tradition.audioSource} />
        </div>

        {/* View Switcher & Action Controls */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-b border-[#E5DDD0] pb-2">
          <div className="flex items-center flex-wrap gap-1">
            <button
              onClick={() => setActiveTab("regional")}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all cursor-pointer ${
                activeTab === "regional"
                  ? "bg-[#1B4332] text-white font-semibold shadow-xs"
                  : "bg-[#EFE9DF] text-[#1B4332] hover:bg-[#E5DDD0] font-medium"
              }`}
            >
              <Headphones size={13} className={activeTab === "regional" ? "text-amber-300" : "text-[#A64B2A]"} />
              <span>🎧 Regional Voice & Narration (हिन्दी · Regional · English)</span>
            </button>
            <button
              onClick={() => setActiveTab("sideBySide")}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === "sideBySide"
                  ? "bg-[#1B4332] text-white font-semibold"
                  : "text-[#6B655B] hover:bg-[#EFE9DF]"
              }`}
            >
              Side-by-Side View
            </button>
            <button
              onClick={() => setActiveTab("original")}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === "original"
                  ? "bg-[#1B4332] text-white font-semibold"
                  : "text-[#6B655B] hover:bg-[#EFE9DF]"
              }`}
            >
              Original Story Only
            </button>
            <button
              onClick={() => setActiveTab("translation")}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === "translation"
                  ? "bg-[#1B4332] text-white font-semibold"
                  : "text-[#6B655B] hover:bg-[#EFE9DF]"
              }`}
            >
              English Translation Only
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Copy Citation */}
            <button
              onClick={handleCopyCitation}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-[#1B4332] hover:text-[#2D6A4F] px-2.5 py-1 rounded hover:bg-[#EFE9DF] transition-colors cursor-pointer"
              title="Copy standard archival citation"
            >
              {copied ? <Check size={14} className="text-emerald-700" /> : <Copy size={14} />}
              <span>{copied ? "Citation Copied" : "Cite Record"}</span>
            </button>
          </div>
        </div>

        {/* Presentation Content */}
        <div className="mt-6">
          {activeTab === "regional" && (
            <div className="animate-fade-in">
              <RegionalNarrationPlayer tradition={tradition} />
            </div>
          )}
          {activeTab === "sideBySide" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Original Story Container */}
              <div className="bg-white border border-[#E5DDD0] rounded-lg p-5">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#F0EAE1]">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1B4332]">
                    <BookOpen size={14} />
                    <span>Original Story ({tradition.language})</span>
                  </div>
                  <span className="text-[11px] text-[#8B8477] uppercase tracking-wide">
                    Unchanged Voice
                  </span>
                </div>
                <div className="text-sm text-[#22201D] leading-relaxed whitespace-pre-wrap font-serif">
                  {tradition.originalText}
                </div>
              </div>

              {/* English Translation Container */}
              <div className="bg-[#FAF8F5] border border-[#E5DDD0] rounded-lg p-5">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#F0EAE1]">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#A64B2A]">
                    <Globe size={14} />
                    <span>English Translation</span>
                  </div>
                  <span className="text-[11px] text-[#8B8477] uppercase tracking-wide">
                    AI Curator Reading
                  </span>
                </div>
                <div className="text-sm text-[#332E27] leading-relaxed whitespace-pre-wrap font-serif">
                  {tradition.curatorNotes?.englishTranslation || (
                    <span className="italic text-[#8B8477]">
                      English translation pending or identical to original text.
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "original" && (
            <div className="bg-white border border-[#E5DDD0] rounded-lg p-6 max-w-2xl mx-auto">
              <div className="text-xs uppercase tracking-wider text-[#8B8477] font-semibold mb-3">
                Original Language: {tradition.language}
              </div>
              <div className="text-base text-[#22201D] leading-relaxed whitespace-pre-wrap font-serif">
                {tradition.originalText}
              </div>
            </div>
          )}

          {activeTab === "translation" && (
            <div className="bg-white border border-[#E5DDD0] rounded-lg p-6 max-w-2xl mx-auto">
              <div className="text-xs uppercase tracking-wider text-[#A64B2A] font-semibold mb-3">
                English Translation (AI Curatorial Reading)
              </div>
              <div className="text-base text-[#22201D] leading-relaxed whitespace-pre-wrap font-serif">
                {tradition.curatorNotes?.englishTranslation || tradition.originalText}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="mt-8 pt-4 border-t border-[#E5DDD0] flex items-center justify-between text-xs text-[#8B8477]">
          <div>Consent verified by contributor for open cultural preservation.</div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#EFE9DF] hover:bg-[#E5DDD0] text-[#1B4332] font-semibold rounded-md transition-colors cursor-pointer"
          >
            Close Record
          </button>
        </div>
      </div>
    </div>
  );
};
