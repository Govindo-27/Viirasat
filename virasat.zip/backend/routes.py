"""
Flask API routes blueprint for Virasat Cultural Heritage Archive.
"""
from datetime import datetime
from flask import Blueprint, request, jsonify
from backend.storage import get_all_contributions, get_contribution_by_id, save_contribution
from backend.curator import VirasatHeritageCurator

api_bp = Blueprint("api", __name__, url_prefix="/api")
curator = VirasatHeritageCurator()


@api_bp.route("/status", methods=["GET"])
def get_status():
    """System health check and AI status."""
    info = curator.check_status()
    items = get_all_contributions()
    return jsonify({
        "status": "online",
        "archiveEntries": len(items),
        "storage": "JSON prototype (data/contributions.json)",
        "aiCurator": "Cloud AI Heritage Engine (Zero Setup Required)",
        "details": info,
    })


@api_bp.route("/contributions", methods=["GET"])
def list_contributions():
    """Retrieve saved tradition contributions with search and filter support."""
    q = request.args.get("q", "").strip().lower()
    category = request.args.get("category", "").strip()
    language = request.args.get("language", "").strip()

    items = get_all_contributions()

    if category and category != "All":
        items = [it for it in items if it.get("category", "").lower() == category.lower()]

    if language and language != "All":
        items = [it for it in items if language.lower() in it.get("language", "").lower()]

    if q:
        filtered = []
        for it in items:
            title_match = q in it.get("title", "").lower()
            text_match = q in it.get("originalText", "").lower()
            reg_match = q in it.get("region", "").lower()
            sum_match = q in it.get("curatorNotes", {}).get("summary", "").lower()
            tags_match = any(q in t.lower() for t in it.get("curatorNotes", {}).get("tags", []))
            trans_match = q in it.get("curatorNotes", {}).get("englishTranslation", "").lower()
            if title_match or text_match or reg_match or sum_match or tags_match or trans_match:
                filtered.append(it)
        items = filtered

    return jsonify({
        "success": True,
        "count": len(items),
        "data": items
    })


@api_bp.route("/contributions/<entry_id>", methods=["GET"])
def get_contribution(entry_id):
    """Retrieve a single tradition entry by ID."""
    item = get_contribution_by_id(entry_id)
    if not item:
        return jsonify({"success": False, "error": "Tradition not found"}), 404
    return jsonify({"success": True, "data": item})


@api_bp.route("/curate", methods=["POST"])
def curate_preview():
    """On-demand AI heritage curator for a tradition before saving."""
    data = request.get_json() or {}
    title = data.get("title", "").strip()
    original_text = data.get("originalText", "").strip()
    language = data.get("language", "Unknown").strip()
    category = data.get("category", "Stories").strip()
    region = data.get("region", "").strip()

    if not title or not original_text:
        return jsonify({"success": False, "error": "Title and original text are required."}), 400

    curation = curator.curate_tradition(
        title=title,
        original_text=original_text,
        language=language,
        category=category,
        region=region
    )

    curation["generatedAt"] = datetime.utcnow().isoformat() + "Z"
    return jsonify({"success": True, "data": curation})


@api_bp.route("/contributions", methods=["POST"])
def create_contribution():
    """Validate and preserve a new tradition in the archive."""
    data = request.get_json() or {}
    title = data.get("title", "").strip()
    original_language = data.get("originalLanguage", "").strip()
    category = data.get("category", "").strip()
    region = data.get("region", "").strip()
    original_text = data.get("originalText", "").strip()
    contributor_name = data.get("contributorName", "").strip() or "Community Contributor"
    consent_given = data.get("consentGiven", False)
    curator_notes = data.get("curatorNotes")

    # Validation
    if len(title) < 3:
        return jsonify({"success": False, "error": "Title must be at least 3 characters."}), 400
    if not original_language:
        return jsonify({"success": False, "error": "Original language is required."}), 400
    if not category:
        return jsonify({"success": False, "error": "Category is required."}), 400
    if len(original_text) < 15:
        return jsonify({"success": False, "error": "Tradition text must be at least 15 characters."}), 400
    if not consent_given:
        return jsonify({"success": False, "error": "Consent acknowledgment is required to preserve traditions."}), 400

    if not curator_notes or not curator_notes.get("summary"):
        curator_notes = curator.curate_tradition(
            title=title,
            original_text=original_text,
            language=original_language,
            category=category,
            region=region
        )
        curator_notes["generatedAt"] = datetime.utcnow().isoformat() + "Z"

    record = {
        "title": title,
        "category": category,
        "language": original_language,
        "region": region or "Unspecified Region",
        "contributorName": contributor_name,
        "datePreserved": datetime.utcnow().strftime("%Y-%m-%d"),
        "originalText": original_text,
        "consentGiven": True,
        "verifiedStatus": "Unverified Community Contribution",
        "curatorNotes": curator_notes,
    }

    saved = save_contribution(record)
    return jsonify({"success": True, "data": saved}), 201


@api_bp.route("/ask", methods=["POST"])
def ask_archive():
    """Ask questions strictly grounded in saved traditions."""
    data = request.get_json() or {}
    question = data.get("question", "").strip()

    if not question:
        return jsonify({"success": False, "error": "A question is required."}), 400

    items = get_all_contributions()
    answer, cited, model_used = curator.ask_archive(question, items)

    return jsonify({
        "success": True,
        "answer": answer,
        "citedEntries": cited,
        "modelUsed": model_used,
        "archiveEntriesCount": len(items)
    })
