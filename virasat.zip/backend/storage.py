"""
Storage module for Virasat Cultural Heritage Archive.
Handles loading and saving contributions to JSON file storage.
"""
import os
import json
from typing import List, Dict, Any, Optional

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
STORAGE_FILE = os.path.join(DATA_DIR, "contributions.json")


def ensure_storage_exists() -> None:
    """Ensure data directory and contributions.json file exist."""
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(STORAGE_FILE):
        with open(STORAGE_FILE, "w", encoding="utf-8") as f:
            json.dump([], f, ensure_ascii=False, indent=2)


def get_all_contributions() -> List[Dict[str, Any]]:
    """Retrieve all saved contributions."""
    ensure_storage_exists()
    try:
        with open(STORAGE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"Error reading {STORAGE_FILE}: {e}")
        return []


def get_contribution_by_id(entry_id: str) -> Optional[Dict[str, Any]]:
    """Retrieve a single contribution by ID."""
    items = get_all_contributions()
    for item in items:
        if item.get("id") == entry_id:
            return item
    return None


def save_contribution(contribution: Dict[str, Any]) -> Dict[str, Any]:
    """Append a new contribution to storage with an auto-generated accession ID."""
    ensure_storage_exists()
    items = get_all_contributions()
    
    # Generate accession ID
    year = "2026"
    next_num = len(items) + 1
    new_id = f"VIR-{year}-{str(next_num).zfill(3)}"
    contribution["id"] = new_id
    
    # Store at beginning of list so latest appears first
    items.insert(0, contribution)
    
    with open(STORAGE_FILE, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)
        
    return contribution
